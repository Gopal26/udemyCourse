import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import { Icon } from 'react-fa';
import Loading from './../Loading/loading';
import './user-info.css';

class UserInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showLoading: false,
            showLogout: false
        };
    }

    showLoading() {
        this.setState({ showLoading: true });
    }

    toggleShowLogout() {
        this.setState({ showLogout: !this.state.showLogout });
    }

    openLoginPage(history) {
        sessionStorage.setItem('DVUserName', null);
        history.replace('/');
    }

    logoutUser(history) {
        this.showLoading();
        setTimeout(() => this.openLoginPage(history), 2500);
    }

    render() {
        const { showLoading, showLogout } = this.state;
        const className = !showLogout ? 'hide' : null;
        const iconName = !showLogout ? 'angle-down' : 'angle-up';

        return (
            <div>
                {showLoading && (
                    <Loading />
                )}

                <div className="user-info">
                    <div
                        className="details"
                        onClick={() => this.toggleShowLogout()}
                    >
                        <Icon className="profile-image" name="user" />
                        <span className="user-name">{sessionStorage.DVUserName}</span>
                        <Icon className="down-arrow" name={iconName} />
                    </div>

                    <div className={`logout ${className}`}>
                        <Route render={({ history }) => (
                            <button onClick={() => this.logoutUser(history)}>
                                Logout <Icon name="sign-out" />
                            </button>
                        )} />
                    </div>
                </div>
            </div>
        );
    }
}

export default UserInfo;
