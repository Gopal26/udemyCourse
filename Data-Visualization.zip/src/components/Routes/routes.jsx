import React from 'react';
import { Switch, Route } from 'react-router-dom';
import Login from './../Login/login';
import Details from './../Details/details';

const Routes = () => {
  return (
    <Switch>
      <Route exact path='/' component={Login}/>
      <Route exact path='/details' component={Details}/>
    </Switch>
  );
};

export default Routes;
