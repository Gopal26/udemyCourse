import React from 'react';
import getClassName from './../../helpers/get-class-name';
import './visualization.css';

const Visualization = props => {
    const { selectedTableName, selectedTableDependencies } = props;

    const renderDependencyDetails = (dependency) => {
        return (
            <div className="dependency-details">
                <div className="table-name">{dependency.name}</div>
                <div className="time-remaining">
                    <label>Time Remaining:</label>
                    {dependency.timeRemaining || 'Not Available'}
                </div>
                <div className="last-updated">
                    <label>Last Updated:</label>
                    {dependency.lastUpdated || 'Not Available'}
                </div>
            </div>
        )
    };

    const renderTableDependencies = () => {
        return (
            selectedTableDependencies.map((dependency, index) => {
                const className = dependency.status.split(' ').join('-').toLowerCase();

                return (
                    <li
                        key={index}
                        className={className}
                    >
                        {renderDependencyDetails(dependency)}
                    </li>
                )
            })
        );
    };

    return (
        <div className="visualization">
            <header className={getClassName(selectedTableDependencies)}>{selectedTableName}</header>

            <div className="dependencies">
                <ul>
                    {renderTableDependencies()}
                </ul>
            </div>
        </div>
    );
};

export default Visualization;
