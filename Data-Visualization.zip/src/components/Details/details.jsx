import React, { Component } from 'react';
import { first } from 'lodash';
import VisualizationDetails from './../../data/visualization-details.json';
import UserInfo from './../UserInfo/user-info';
import Menu from './../Menu/menu';
import Visualization from './../Visualization/visualization';
import './details.css';

class Details extends Component {
    constructor(props) {
        super(props);

        this.state = {
            tableList: null,
            selectedTableName: null,
            selectedTableDependencies: null
        };
    }

    componentDidMount() {
        const tableList = [];

        VisualizationDetails.forEach(table => {
            tableList.push(table.name);
        });

        this.setState({
            tableList: tableList,
            selectedTableName: first(VisualizationDetails).name,
            selectedTableDependencies: first(VisualizationDetails).dependencies
        });
    }

    filterTableList(searchText) {
        const tableList = [];

        VisualizationDetails.forEach(table => {
            if (table.name.toLowerCase().includes(searchText.toLowerCase())) {
                tableList.push(table.name);
            }
        });

        this.setState({ tableList: tableList });
    }

    setSelectedTableNameAndDependencies(tableName) {
        let tableDependencies;

        VisualizationDetails.forEach(table => {
            if (table.name === tableName) {
                tableDependencies = table.dependencies;
            }
        });

        this.setState({
            selectedTableName: tableName,
            selectedTableDependencies: tableDependencies
        })
    }

    render() {
        const { tableList, selectedTableName, selectedTableDependencies } = this.state;

        return (
            <div className="details-container">
                <UserInfo />

                {tableList && selectedTableName && (
                    <Menu
                        tableList={tableList}
                        selectedTableName={selectedTableName}
                        filterTableList={this.filterTableList.bind(this)}
                        setSelectedTableNameAndDependencies={this.setSelectedTableNameAndDependencies.bind(this)}
                    />
                )}

                {selectedTableName && selectedTableDependencies && (
                    <Visualization
                        selectedTableName={selectedTableName}
                        selectedTableDependencies={selectedTableDependencies}
                    />
                )}
            </div>
        );
    }
}

export default Details;
