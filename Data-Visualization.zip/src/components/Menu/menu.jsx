import React from 'react';
import { Icon } from 'react-fa';
import './menu.css';

const Menu = props => {
    const { tableList, selectedTableName } = props;

    const renderTableList = () => {
        if (tableList.length) {
            return (
                tableList.map((tableName, index) => {
                    const className = tableName === selectedTableName ? 'selected' : null;

                    return (
                        <li
                            key={index}
                            className={className}
                            onClick={() => props.setSelectedTableNameAndDependencies(tableName)}
                        >
                            {tableName}
                        </li>
                    );
                })
            );
        }

        return (
            <div className="no-result">
                No search result found
            </div>
        );
    };

    return (
        <div className="menu">
            <div className="search-box">
                <Icon name="search" />
                <input
                    type="text"
                    placeholder="Enter search text"
                    onChange={input => props.filterTableList(input.target.value)}
                />
            </div>

            <ul>
                {renderTableList()}
            </ul>
        </div>
    );
};

export default Menu;
