import React from 'react';
import AsurionLogo from './../../assets/images/asurion-logo.png';
import './header.css';

const Header = () => {
    return (
        <header className="app-header">
            <img alt="unable to load" src={AsurionLogo} />
        </header>
    );
};

export default Header;
