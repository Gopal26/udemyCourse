import React from 'react';
import { Icon } from 'react-fa';
import './loading.css';

const Loading = () => {
    return (
        <div className="loading">
            <div className="loading-icon">
                <Icon className="spinner" name="spinner" spin />
            </div>
        </div>
    );
};

export default Loading;
