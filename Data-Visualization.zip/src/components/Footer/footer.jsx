import React from 'react';
import SynechronLogo from './../../assets/images/synechron-logo.png';
import './footer.css';

const Footer = () => {
    return (
        <footer className="app-footer">
            <img alt="unable to load" src={SynechronLogo} />
        </footer>
    );
};

export default Footer;
