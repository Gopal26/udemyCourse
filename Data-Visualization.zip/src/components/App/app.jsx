import React from 'react';
import Header from './../Header/header';
import Content from './../Content/content';
import Footer from './../Footer/footer';
import './app.css';

const App = () => {
    return (
        <div className="data-visualization">
            <Header />
            <Content />
            <Footer />
        </div>
    );
}

export default App;
