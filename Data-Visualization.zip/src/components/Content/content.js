import React from 'react';
import Routes from './../Routes/routes';
import './content.css';

const Content = () => {
    return (
        <div className="content-container">
            <Routes />
        </div>
    );
};

export default Content;
