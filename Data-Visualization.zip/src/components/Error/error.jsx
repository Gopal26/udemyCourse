import React from 'react';
import { Icon } from 'react-fa';
import './error.css';

const Error = props => {
    const { errorBody } = props;
    const className = !errorBody ? 'hide' : null;

    return (
        <div className={`error ${className}`}>
            {errorBody}
            <Icon
                className="close-error"
                name="remove"
                onClick={() => props.closeError()}
            />
        </div>
    );
};

export default Error;
