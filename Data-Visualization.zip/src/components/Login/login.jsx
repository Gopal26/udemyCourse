import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import { Icon } from 'react-fa';
import UserDetails from './../../data/users.json';
import Error from './../Error/error';
import Loading from './../Loading/loading';
import './login.css';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showLoading: false,
            errorBody: null
        };
    }

    showLoading() {
        this.setState({ showLoading: true });
    }

    closeError() {
        this.setState({
            errorBody: null
        });
    }

    showError(errorBody) {
        this.setState({
            errorBody: errorBody
        });
    }

    openDetailsPage(history) {
        history.push('/details');
    }

    validateUser(history) {
        const username = this.username.value;
        const password = this.password.value;

        if (username !== '' && password !== '') {
            if (username === UserDetails.userName && password === UserDetails.userPassword) {
                sessionStorage.setItem('DVUserName', UserDetails.displayName);
                
                this.showLoading();
                setTimeout(() => this.openDetailsPage(history), 2500);
            } else {
                this.showError('Invalid credentials');
            }
        } else {
            this.showError('Enter credentials');
        }
    };

    triggerButtonClickEvent(evt) {
        if (evt.key.toLowerCase() === 'enter' || evt.keyCode === 13) {
            this.signinbutton.click();
        }
    }

    render() {
        const { showLoading, errorBody } = this.state;

        return (
            <div>
                {showLoading && (
                    <Loading />
                )}

                <div className="login-container">
                    <Error
                        errorBody={errorBody}
                        closeError={this.closeError.bind(this)}
                    />

                    <div className="field">
                        <label>Username</label>
                        <input
                            ref={input => (this.username = input)}
                            type="text"
                            placeholder="Enter Username"
                            onKeyUp={evt => this.triggerButtonClickEvent(evt)}
                        />
                    </div>

                    <div className="field">
                        <label>Password</label>
                        <input
                            ref={input => (this.password = input)}
                            type="password"
                            placeholder="Enter Password"
                            onKeyUp={evt => this.triggerButtonClickEvent(evt)}
                        />
                    </div>

                    <Route render={({ history }) => (
                        <button
                            ref={button => (this.signinbutton = button)}
                            onClick={() => this.validateUser(history)}
                        >
                            Login <Icon name="sign-in" />
                        </button>
                    )} />
                </div>
            </div>
        );
    }
};

export default Login;
