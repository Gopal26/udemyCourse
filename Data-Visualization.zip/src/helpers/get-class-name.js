const getClassName = (tableDependencies) => {
    let className = 'completed';

    tableDependencies.forEach(table => {
        if (table.status === 'Not Started') {
            className = 'not-started';
        } else if (table.status === 'In Progress' && className !== 'not-started') {
            className = 'in-progress';
        }
    });

    return className;
};

export default getClassName;
